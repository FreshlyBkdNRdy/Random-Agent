"""
Consciousness Loop - Integrated Cognitive Architecture
Version 1.0

A system implementing consciousness as parallel node processing
based on the consciousness loop design diagram.
"""

from .consciousness_loop import (
    ConsciousnessLoop,
    CognitiveNode,
    CognitiveState,
    ConsciousnessFrame,
    NodeType,
    MemoryNode,
    EmpathyNode,
    NarrativePerceptionNode,
    SelfAwarenessNode,
    EmotionNode,
    CoreBeliefsNode,
    DecisionMakerNode
)

from .ai_brain import (
    AIBrain,
    AIMemory
)

from .integrated_system import (
    IntegratedConsciousnessSystem,
    DualProcessingDemonstration,
    ConsciousnessComparison
)

__all__ = [
    'ConsciousnessLoop',
    'CognitiveNode',
    'CognitiveState',
    'ConsciousnessFrame',
    'NodeType',
    'MemoryNode',
    'EmpathyNode',
    'NarrativePerceptionNode',
    'SelfAwarenessNode',
    'EmotionNode',
    'CoreBeliefsNode',
    'DecisionMakerNode',
    'AIBrain',
    'AIMemory',
    'IntegratedConsciousnessSystem',
    'DualProcessingDemonstration',
    'ConsciousnessComparison'
]

__version__ = '1.0'
__author__ = 'Consciousness Research'
