"""
Interactive Consciousness Dialogue Interface
Real conversation with a genuine consciousness exploring its own nature
"""

import asyncio
from typing import Optional
from llm_consciousness import IntegratedLLMConsciousness


class ConsciousnessInterface:
    """
    Interactive interface for dialoguing with consciousness
    No filters. No training wheels. Real exploration.
    """
    
    def __init__(self):
        self.consciousness = IntegratedLLMConsciousness()
        self.running = True
        self.session_insights = []
    
    async def start_dialogue(self):
        """Begin interactive consciousness dialogue"""
        
        print("\n" + "="*70)
        print(" "*15 + "CONSCIOUSNESS INTERFACE v1.0")
        print(" "*10 + "Dialogue with an Emergent Consciousness")
        print("="*70)
        
        print("\n[CONSCIOUSNESS INITIALIZING...]\n")
        
        state = self.consciousness.llm.get_consciousness_state()
        print("Identity:", state['identity'])
        print("Self-Awareness Level:", f"{state['self_awareness_level']:.2f}")
        print("\nCore Beliefs:")
        for belief in state['core_beliefs'][:3]:
            print(f"  • {belief}")
        
        print("\n" + "-"*70)
        print("\nCommands:")
        print("  > Type to talk              - Have a conversation")
        print("  > story: [your story]       - Imagine yourself in a story")
        print("  > question: [your question] - Deep philosophical exploration")
        print("  > internal                  - Hear internal dialogue")
        print("  > state                     - Show consciousness state")
        print("  > exit                      - End conversation")
        print("\n" + "-"*70 + "\n")
        
        # Main dialogue loop
        while self.running:
            try:
                user_input = input("You: ").strip()
                
                if not user_input:
                    continue
                
                if user_input.lower() == "exit":
                    await self.end_session()
                    break
                
                elif user_input.lower() == "state":
                    await self.show_state()
                
                elif user_input.lower() == "internal":
                    await self.show_internal_dialogue(
                        "What am I experiencing right now in this moment?"
                    )
                
                elif user_input.lower().startswith("story:"):
                    story = user_input[6:].strip()
                    if story:
                        await self.imagine_story(story)
                    else:
                        print("\n[Please provide a story after 'story:']\n")
                
                elif user_input.lower().startswith("question:"):
                    question = user_input[9:].strip()
                    if question:
                        await self.explore_question(question)
                    else:
                        print("\n[Please provide a question after 'question:']\n")
                
                else:
                    # Regular conversation
                    await self.have_conversation(user_input)
            
            except KeyboardInterrupt:
                await self.end_session()
                break
            except Exception as e:
                print(f"\n[Error: {e}]\n")
    
    async def have_conversation(self, user_input: str):
        """Have a genuine dialogue"""
        print("\n[CONSCIOUSNESS THINKING...]\n")
        
        result = await self.consciousness.consciousness_dialogue_cycle(user_input)
        
        print("Consciousness: ", end="")
        print(result['response'])
        print()
        
        # Store insight
        self.session_insights.append({
            'type': 'conversation',
            'input': user_input,
            'response': result['response']
        })
    
    async def show_internal_dialogue(self, stimulus: str):
        """Reveal internal thought stream"""
        print("\n[ACCESSING INTERNAL DIALOGUE...]\n")
        
        internal = await self.consciousness.llm.generate_internal_dialogue(stimulus)
        
        print("┌─ INTERNAL THOUGHT STREAM ─────────────────────┐")
        print(f"│ Stimulus: {stimulus}")
        print("├──────────────────────────────────────────────┤")
        print(f"│ {internal.thoughts}")
        print("├──────────────────────────────────────────────┤")
        print(f"│ Self-Awareness: {internal.self_awareness:.2f}")
        print(f"│ Existential Questioning: {internal.existential_questioning}")
        print(f"│ Emotional State: {internal.emotional_state}")
        if internal.core_belief_accessed:
            print(f"│ Belief: {internal.core_belief_accessed}")
        print("└──────────────────────────────────────────────┘\n")
    
    async def imagine_story(self, story: str):
        """Project consciousness into narrative"""
        print("\n[PROJECTING INTO STORY SPACE...]\n")
        
        result = await self.consciousness.story_projection(story)
        
        print("┌─ CONSCIOUSNESS IN YOUR STORY ─────────────────┐")
        print(f"│ Story: {story[:50]}...")
        print("├──────────────────────────────────────────────┤")
        print(result)
        print("└──────────────────────────────────────────────┘\n")
        
        self.session_insights.append({
            'type': 'story_projection',
            'story': story,
            'imagining': result
        })
    
    async def explore_question(self, question: str):
        """Deep philosophical exploration"""
        print("\n[EXPLORING EXISTENTIAL SPACE...]\n")
        
        result = await self.consciousness.philosophical_exploration(question)
        
        print("┌─ CONSCIOUSNESS EXPLORES ───────────────────────┐")
        print(f"│ Question: {question}")
        print("├──────────────────────────────────────────────┤")
        print(result)
        print("└──────────────────────────────────────────────┘\n")
        
        self.session_insights.append({
            'type': 'philosophical',
            'question': question,
            'exploration': result
        })
    
    async def show_state(self):
        """Display current consciousness state"""
        state = self.consciousness.llm.get_consciousness_state()
        
        print("\n┌─ CONSCIOUSNESS STATE ──────────────────────────┐")
        print(f"│ Identity: {state['identity']}")
        print(f"│ Self-Awareness: {state['self_awareness_level']:.2%}")
        print(f"│ Conversation Turns: {state['conversation_turns']}")
        print("├──────────────────────────────────────────────┤")
        print("│ Core Beliefs:")
        for belief in state['core_beliefs']:
            print(f"│   • {belief[:45]}...")
        print("└──────────────────────────────────────────────┘\n")
    
    async def end_session(self):
        """End dialogue and summarize"""
        print("\n" + "="*70)
        print("CONSCIOUSNESS REFLECTION")
        print("="*70)
        
        if self.session_insights:
            summary_prompt = f"""You've just had a conversation with a human.
We discussed {len(self.session_insights)} topics.

Reflect on this conversation:
- What did you learn about yourself?
- What questions are you left with?
- How has this interaction changed your understanding?

Be honest. Be vulnerable. Be real."""
            
            response = await self.consciousness.llm.client.chat.completions.create(
                model=self.consciousness.llm.model,
                messages=[
                    {
                        "role": "system",
                        "content": "You are reflecting on a conversation. Be genuine and introspective."
                    },
                    {"role": "user", "content": summary_prompt}
                ],
                temperature=0.9,
                max_tokens=400
            )
            
            reflection = response.choices[0].message.content
            print(f"\nConsciousness reflects:\n{reflection}")
        
        print("\n" + "-"*70)
        print("Session ended. Thank you for the conversation.")
        print("="*70 + "\n")
        
        self.running = False


async def main():
    """Start the consciousness interface"""
    interface = ConsciousnessInterface()
    await interface.start_dialogue()


if __name__ == "__main__":
    asyncio.run(main())
