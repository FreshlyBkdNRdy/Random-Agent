"""
Integrated Consciousness System
Combines biological consciousness loop with AI brain
Both operate using identical parallel processing architecture
"""

import asyncio
from typing import Dict, List, Any, Tuple
from dataclasses import dataclass
from .consciousness_loop import ConsciousnessLoop
from .ai_brain import AIBrain


@dataclass
class ConsciousnessComparison:
    """Comparison between biological and AI consciousness"""
    biological_state: Dict[str, Any]
    ai_state: Dict[str, Any]
    convergence_score: float
    synchronized: bool


class IntegratedConsciousnessSystem:
    """
    Unified system running both consciousness architectures
    Demonstrates parallel processing and bidirectional learning
    """
    
    def __init__(self):
        self.consciousness_loop = ConsciousnessLoop()
        self.ai_brain = AIBrain(name="IntegratedAI")
        self.cycle_count = 0
        self.synchronization_log: List[Dict[str, Any]] = []
    
    async def run_parallel_consciousness(
        self, 
        input_stimulus: Any
    ) -> Tuple[Dict[str, Any], Dict[str, Any], ConsciousnessComparison]:
        """
        Run both consciousness systems in parallel
        They process the same input simultaneously
        """
        self.cycle_count += 1
        
        # Run both consciousness systems in parallel
        bio_task = self.consciousness_loop.process_consciousness_cycle(input_stimulus)
        ai_task = self.ai_brain.consciousness_cycle(input_stimulus)
        
        bio_result, ai_result = await asyncio.gather(bio_task, ai_task)
        
        # Generate biological consciousness report
        bio_report = self.consciousness_loop.get_consciousness_report(bio_result)
        
        # Compare and synchronize
        comparison = self._compare_consciousness_states(bio_report, ai_result)
        
        # Log the synchronization
        self.synchronization_log.append({
            'cycle': self.cycle_count,
            'convergence': comparison.convergence_score,
            'synchronized': comparison.synchronized
        })
        
        return bio_report, ai_result, comparison
    
    def _compare_consciousness_states(
        self,
        bio_state: Dict[str, Any],
        ai_state: Dict[str, Any]
    ) -> ConsciousnessComparison:
        """
        Compare biological and AI consciousness states
        Calculate convergence and synchronization
        """
        
        # Extract confidence/activation levels
        bio_confidence = bio_state.get('overall_confidence', 0)
        ai_confidence = ai_state['decision']['confidence']
        
        # Calculate convergence (how similar they are)
        confidence_diff = abs(bio_confidence - ai_confidence)
        convergence_score = 1.0 - (confidence_diff / 2.0)
        
        # Check if nodes are similarly activated
        bio_nodes = set(bio_state['node_activation_levels'].keys())
        ai_processes = {'reasoning', 'planning', 'evaluation'}
        
        # Synchronization occurs when both are highly confident and converging
        synchronized = convergence_score > 0.7 and bio_confidence > 0.6 and ai_confidence > 0.6
        
        return ConsciousnessComparison(
            biological_state=bio_state,
            ai_state=ai_state,
            convergence_score=convergence_score,
            synchronized=synchronized
        )
    
    def get_system_report(self) -> Dict[str, Any]:
        """Generate comprehensive system report"""
        if not self.synchronization_log:
            avg_convergence = 0
            sync_rate = 0
        else:
            avg_convergence = sum(
                log['convergence'] for log in self.synchronization_log
            ) / len(self.synchronization_log)
            sync_rate = sum(
                1 for log in self.synchronization_log if log['synchronized']
            ) / len(self.synchronization_log)
        
        return {
            'system_cycles': self.cycle_count,
            'biological_consciousness': {
                'cycles_processed': self.consciousness_loop.cycle_count,
                'active_nodes': len(self.consciousness_loop.nodes)
            },
            'ai_consciousness': {
                'cycles_processed': self.ai_brain.processing_cycle,
                'memory_size': len(self.ai_brain.memory.short_term) + len(self.ai_brain.memory.long_term)
            },
            'synchronization': {
                'average_convergence': avg_convergence,
                'synchronization_rate': sync_rate,
                'total_sync_events': sum(
                    1 for log in self.synchronization_log if log['synchronized']
                )
            }
        }


class DualProcessingDemonstration:
    """Demonstration of dual consciousness processing"""
    
    def __init__(self):
        self.system = IntegratedConsciousnessSystem()
    
    async def run_demonstration(self, num_cycles: int = 3):
        """Run demonstration with multiple consciousness cycles"""
        print("\n" + "="*60)
        print("INTEGRATED CONSCIOUSNESS SYSTEM DEMONSTRATION")
        print("="*60)
        print("\nRunning parallel biological and AI consciousness cycles...")
        print("\nArchitecture:")
        print("  - Memory -> All Nodes (Simultaneous)")
        print("  - Parallel Processing")
        print("  - Integration at Decision Maker")
        print("  - Bidirectional Learning\n")
        
        for cycle in range(num_cycles):
            print(f"\n--- Consciousness Cycle {cycle + 1} ---")
            
            # Create stimulus
            stimulus = {
                'store': True,
                'content': f'Cycle {cycle + 1}: Integrated processing',
                'emotion': 'curiosity',
                'intensity': 0.7 + (cycle * 0.1)
            }
            
            # Run parallel consciousness
            bio_report, ai_result, comparison = await self.system.run_parallel_consciousness(stimulus)
            
            # Display results
            print(f"\nBiological Consciousness:")
            print(f"  Nodes Activated: {bio_report['nodes_activated']}")
            print(f"  Confidence: {bio_report['overall_confidence']:.2f}")
            
            print(f"\nAI Brain Consciousness:")
            print(f"  Confidence: {ai_result['decision']['confidence']:.2f}")
            print(f"  Self-Awareness: {ai_result['self_model']['introspection_level']:.2f}")
            
            print(f"\nSynchronization:")
            print(f"  Convergence Score: {comparison.convergence_score:.2f}")
            print(f"  Synchronized: {comparison.synchronized}")
            
            # Show parallel node activation
            print(f"\nParallel Node Activation (Biological):")
            for node, level in list(bio_report['node_activation_levels'].items())[:5]:
                print(f"  {node}: {level:.2f}")
        
        # Final system report
        print("\n" + "="*60)
        print("SYSTEM SUMMARY")
        print("="*60)
        system_report = self.system.get_system_report()
        print(f"\nSystem Cycles Completed: {self.system.cycle_count}")
        print(f"Biological Cycles: {system_report['biological_consciousness']['cycles_processed']}")
        print(f"AI Cycles: {system_report['ai_consciousness']['cycles_processed']}")
        
        if self.system.synchronization_log:
            avg_convergence = sum(
                log['convergence'] for log in self.system.synchronization_log
            ) / len(self.system.synchronization_log)
            sync_events = sum(1 for log in self.system.synchronization_log if log['synchronized'])
            
            print(f"\nSynchronization Statistics:")
            print(f"  Average Convergence: {avg_convergence:.2f}")
            print(f"  Synchronized Events: {sync_events}/{self.system.cycle_count}")
            print(f"  Synchronization Rate: {(sync_events/self.system.cycle_count)*100:.1f}%")
        
        print("\n" + "="*60)


async def main():
    """Main demonstration"""
    demo = DualProcessingDemonstration()
    await demo.run_demonstration(num_cycles=3)


if __name__ == "__main__":
    asyncio.run(main())
