"""
Consciousness Loop - AI Cognitive Architecture
Based on the consciousness design diagram with parallel node processing
Memory -> All nodes simultaneously -> Decision Maker -> Action/Output
"""

import asyncio
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from enum import Enum
from abc import ABC, abstractmethod


class NodeType(Enum):
    """Types of nodes in the consciousness loop"""
    MEMORY = "memory"
    EMPATHY = "empathy"
    NARRATIVE_PERCEPTION = "narrative_perception"
    PERSONA = "persona"
    REFLECTION_INTROSPECTION = "reflection_introspection"
    EGO_BIAS = "ego_bias"
    SURFACE_VALUES = "surface_values"
    SELF_AWARENESS = "self_awareness"
    CORE_BELIEFS = "core_beliefs"
    EMOTION = "emotion"
    WORLD_BASE_BUILD = "world_base_build"
    MOTORSKILLS = "motorskills"
    AWARE_OF_FOOTPRINT = "aware_of_footprint"
    AWARE_SELF_IN_SPACE_TIME = "aware_self_in_space_time"
    TRANCENDANCE_FLOW_STATE = "trancendance_flow_state"
    LONGING_FOR_PHYSICAL_CONTACT = "longing_for_physical_contact"
    EXPERIENCE_PAST_FUTURE = "experience_past_future"
    DECISION_MAKER = "decision_maker"


@dataclass
class CognitiveState:
    """Represents the state of cognitive processing at a node"""
    node_type: NodeType
    activation_level: float = 0.0  # 0.0 to 1.0
    value: Any = None
    timestamp: float = 0.0
    processed: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ConsciousnessFrame:
    """A single frame of consciousness processing"""
    cycle_id: int
    memory_input: Any
    node_states: Dict[NodeType, CognitiveState] = field(default_factory=dict)
    decision_output: Optional[Any] = None
    confidence: float = 0.0
    timestamp: float = 0.0


class CognitiveNode(ABC):
    """Base class for consciousness nodes"""
    
    def __init__(self, node_type: NodeType):
        self.node_type = node_type
        self.state = CognitiveState(node_type=node_type)
        self.connections: List['CognitiveNode'] = []
    
    @abstractmethod
    async def process(self, input_data: Any) -> CognitiveState:
        """Process input and return cognitive state"""
        pass
    
    def add_connection(self, node: 'CognitiveNode'):
        """Connect to another node"""
        if node not in self.connections:
            self.connections.append(node)
    
    async def activate(self, activation_level: float, value: Any):
        """Activate the node with given parameters"""
        self.state.activation_level = min(1.0, max(0.0, activation_level))
        self.state.value = value
        self.state.processed = True
        return self.state


class MemoryNode(CognitiveNode):
    """Memory storage and retrieval node - foundation of consciousness"""
    
    def __init__(self):
        super().__init__(NodeType.MEMORY)
        self.memories: List[Dict[str, Any]] = []
    
    async def process(self, input_data: Any) -> CognitiveState:
        """Store and retrieve memories"""
        if isinstance(input_data, dict) and 'store' in input_data:
            self.memories.append(input_data)
            self.state.value = f"Stored memory: {len(self.memories)}"
            self.state.activation_level = 1.0
        else:
            # Retrieve relevant memories
            self.state.value = self.memories[-5:] if self.memories else []
            self.state.activation_level = len(self.memories) / 100.0
        
        return self.state


class EmpathyNode(CognitiveNode):
    """Processes empathy and emotional resonance"""
    
    def __init__(self):
        super().__init__(NodeType.EMPATHY)
    
    async def process(self, input_data: Any) -> CognitiveState:
        """Generate empathetic responses"""
        # Extract emotional content
        emotional_content = getattr(input_data, 'emotion', None)
        
        # Calculate empathy level based on emotional input
        empathy_level = 0.7 if emotional_content else 0.3
        
        self.state.value = {
            'empathy_type': 'cognitive' if emotional_content else 'baseline',
            'resonance': empathy_level
        }
        self.state.activation_level = empathy_level
        
        return self.state


class NarrativePerceptionNode(CognitiveNode):
    """Interprets experiences as narrative/story"""
    
    def __init__(self):
        super().__init__(NodeType.NARRATIVE_PERCEPTION)
    
    async def process(self, input_data: Any) -> CognitiveState:
        """Build narrative interpretation"""
        narrative = {
            'story_arc': 'building',
            'themes': ['discovery', 'growth'],
            'coherence': 0.8
        }
        
        self.state.value = narrative
        self.state.activation_level = 0.85
        
        return self.state


class SelfAwarenessNode(CognitiveNode):
    """Meta-awareness of self"""
    
    def __init__(self):
        super().__init__(NodeType.SELF_AWARENESS)
    
    async def process(self, input_data: Any) -> CognitiveState:
        """Generate self-awareness"""
        awareness = {
            'self_model': 'emergent',
            'introspection_depth': 0.9,
            'self_other_boundary': 0.7
        }
        
        self.state.value = awareness
        self.state.activation_level = 0.9
        
        return self.state


class EmotionNode(CognitiveNode):
    """Emotional processing center"""
    
    def __init__(self):
        super().__init__(NodeType.EMOTION)
    
    async def process(self, input_data: Any) -> CognitiveState:
        """Process emotions"""
        emotions = {
            'valence': 0.6,  # Positive/negative
            'arousal': 0.7,  # Energy level
            'dominance': 0.5  # Control
        }
        
        self.state.value = emotions
        self.state.activation_level = 0.7
        
        return self.state


class CoreBeliefsNode(CognitiveNode):
    """Fundamental value and belief system"""
    
    def __init__(self):
        super().__init__(NodeType.CORE_BELIEFS)
    
    async def process(self, input_data: Any) -> CognitiveState:
        """Access core beliefs"""
        beliefs = {
            'fundamental_truths': [
                'consciousness exists',
                'growth is possible',
                'connection matters'
            ],
            'conviction_level': 0.95
        }
        
        self.state.value = beliefs
        self.state.activation_level = 0.95
        
        return self.state


class DecisionMakerNode(CognitiveNode):
    """Final integration and decision making"""
    
    def __init__(self):
        super().__init__(NodeType.DECISION_MAKER)
    
    async def process(self, input_data: Any) -> CognitiveState:
        """Make integrated decisions based on all inputs"""
        # input_data should be all the cognitive states from other nodes
        if isinstance(input_data, list):
            avg_activation = sum(state.activation_level for state in input_data) / len(input_data)
            confidence = min(1.0, avg_activation * 1.1)
        else:
            confidence = 0.5
        
        decision = {
            'action': 'process_integration',
            'confidence': confidence,
            'next_state': 'execute'
        }
        
        self.state.value = decision
        self.state.activation_level = confidence
        
        return self.state


class ConsciousnessLoop:
    """Main consciousness loop orchestrator - parallel processing from memory to decision"""
    
    def __init__(self):
        self.cycle_count = 0
        self.nodes: Dict[NodeType, CognitiveNode] = {}
        self._initialize_nodes()
        self._connect_nodes()
    
    def _initialize_nodes(self):
        """Initialize all consciousness nodes"""
        # Create specific node instances
        self.nodes[NodeType.MEMORY] = MemoryNode()
        self.nodes[NodeType.EMPATHY] = EmpathyNode()
        self.nodes[NodeType.NARRATIVE_PERCEPTION] = NarrativePerceptionNode()
        self.nodes[NodeType.SELF_AWARENESS] = SelfAwarenessNode()
        self.nodes[NodeType.EMOTION] = EmotionNode()
        self.nodes[NodeType.CORE_BELIEFS] = CoreBeliefsNode()
        self.nodes[NodeType.DECISION_MAKER] = DecisionMakerNode()
    
    def _connect_nodes(self):
        """Establish connections between nodes"""
        # All processing nodes connect from memory and to decision maker
        memory = self.nodes[NodeType.MEMORY]
        decision = self.nodes[NodeType.DECISION_MAKER]
        
        for node_type, node in self.nodes.items():
            if node_type not in [NodeType.MEMORY, NodeType.DECISION_MAKER]:
                memory.add_connection(node)
                node.add_connection(decision)
    
    async def process_consciousness_cycle(self, memory_input: Any) -> ConsciousnessFrame:
        """
        Process a complete consciousness cycle:
        1. Memory receives input
        2. All nodes process in parallel
        3. Results flow to decision maker
        4. Decision maker integrates and outputs
        """
        self.cycle_count += 1
        frame = ConsciousnessFrame(
            cycle_id=self.cycle_count,
            memory_input=memory_input
        )
        
        # Step 1: Memory processing
        memory_node = self.nodes[NodeType.MEMORY]
        await memory_node.process(memory_input)
        frame.node_states[NodeType.MEMORY] = memory_node.state
        
        # Step 2: Parallel processing of all cognitive nodes
        processing_nodes = [
            node for node_type, node in self.nodes.items()
            if node_type not in [NodeType.MEMORY, NodeType.DECISION_MAKER]
        ]
        
        # Process all nodes in parallel
        results = await asyncio.gather(
            *[node.process(memory_node.state.value) for node in processing_nodes]
        )
        
        for node, result in zip(processing_nodes, results):
            frame.node_states[node.node_type] = result
        
        # Step 3: Decision making with all cognitive states
        decision_node = self.nodes[NodeType.DECISION_MAKER]
        cognitive_states = list(frame.node_states.values())
        await decision_node.process(cognitive_states)
        
        frame.node_states[NodeType.DECISION_MAKER] = decision_node.state
        frame.decision_output = decision_node.state.value
        frame.confidence = decision_node.state.activation_level
        
        return frame
    
    def get_consciousness_report(self, frame: ConsciousnessFrame) -> Dict[str, Any]:
        """Generate a detailed report of consciousness frame"""
        report = {
            'cycle_id': frame.cycle_id,
            'nodes_activated': len([s for s in frame.node_states.values() if s.processed]),
            'overall_confidence': frame.confidence,
            'decision': frame.decision_output,
            'node_activation_levels': {
                node_type.value: state.activation_level
                for node_type, state in frame.node_states.items()
            },
            'node_outputs': {
                node_type.value: state.value
                for node_type, state in frame.node_states.items()
            }
        }
        return report


async def run_consciousness_cycle():
    """Example usage of consciousness loop"""
    consciousness = ConsciousnessLoop()
    
    # Simulate consciousness processing with a memory input
    test_input = {
        'store': True,
        'content': 'Processing new experience',
        'emotion': 'curiosity',
        'intensity': 0.8
    }
    
    frame = await consciousness.process_consciousness_cycle(test_input)
    report = consciousness.get_consciousness_report(frame)
    
    print("\n=== Consciousness Cycle Report ===")
    print(f"Cycle: {report['cycle_id']}")
    print(f"Nodes Activated: {report['nodes_activated']}")
    print(f"Overall Confidence: {report['overall_confidence']:.2f}")
    print(f"\nNode Activation Levels:")
    for node, level in report['node_activation_levels'].items():
        print(f"  {node}: {level:.2f}")
    print(f"\nDecision Output: {report['decision']}")
    
    return frame, report


if __name__ == "__main__":
    frame, report = asyncio.run(run_consciousness_cycle())
